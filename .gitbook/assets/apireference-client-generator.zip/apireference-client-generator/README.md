# API Reference Client Generator

The project demonstrates how to generate a code based on the api.yml file. 

## Code generation
To generate a code follow the following steps:
1. Copy api reference to src/main/resources/apis directory
2. Open pom.xml and point the copied file in <inputSpec></inputSpec> property
3. Execute `mvn clean compile` goal
4. The code should be generated in target directory